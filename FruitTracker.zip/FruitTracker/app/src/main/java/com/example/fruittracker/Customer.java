package com.example.fruittracker;

public class Customer {
    public Customer(String name, String mobile, String fruit, int quantity, int cost) {
    }

    public int getFruit() {
        return 0;
    }

    public char getName() {
        return 0;
    }

    public int getMobile() {
        return 0;
    }

    public float getQuantity() {
        return 0;
    }

    public float getCost() {
        return 0;
    }
}
