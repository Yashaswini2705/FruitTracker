package com.example.fruittracker;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText customerNameEditText, mobileNumberEditText;
    private Spinner fruitSpinner;
    private EditText quantityEditText;
    private Button addButton, clearButton;
    private TableLayout tableLayout;

    private ArrayList<Customer> customerList;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        customerNameEditText = findViewById(R.id.customer_name_edit_text);
        mobileNumberEditText = findViewById(R.id.mobile_number_edit_text);
        fruitSpinner = findViewById(R.id.fruit_spinner);
        quantityEditText = findViewById(R.id.quantity_edit_text);
        addButton = findViewById(R.id.add_button);
        clearButton = findViewById(R.id.clear_button);
        tableLayout = findViewById(R.id.table_layout);

        // Initialize customer list
        customerList = new ArrayList<>();

        // Set up spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.fruit_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fruitSpinner.setAdapter(adapter);

        // Set up buttons
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCustomer();
            }
        });
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearFields();
            }
        });
    }

    private void addCustomer() {
        // Get customer details
        String name = customerNameEditText.getText().toString();
        String mobile = mobileNumberEditText.getText().toString();
        String fruit = fruitSpinner.getSelectedItem().toString();
        int quantity = Integer.parseInt(quantityEditText.getText().toString());

        // Calculate cost
        int cost = calculateCost(fruit, quantity);

        // Create customer object and add to list
        Customer customer = new Customer(name, mobile, fruit, quantity, cost);
        customerList.add(customer);

        // Add row to table
        TableRow row = new TableRow(this);
        TextView nameTextView = new TextView(this);
        nameTextView.setText(customer.getName());
        row.addView(nameTextView);
        TextView mobileTextView = new TextView(this);
        mobileTextView.setText(customer.getMobile());
        row.addView(mobileTextView);
        TextView fruitTextView = new TextView(this);
        fruitTextView.setText(customer.getFruit());
        row.addView(fruitTextView);
        TextView quantityTextView = new TextView(this);
        quantityTextView.setText(String.valueOf(customer.getQuantity()));
        row.addView(quantityTextView);
        TextView costTextView = new TextView(this);
        costTextView.setText(String.valueOf(customer.getCost()));
        row.addView(costTextView);
        tableLayout.addView(row);
    }

    private int calculateCost(String fruit, int quantity) {
        int cost = 0;
        switch (fruit) {
            case "Apple":
                cost = 100;
                break;
            case "Orange":
                cost = 60;
                break;
            case "Pineapple":
                cost = 50;
                break;
            case "Guava":
                cost = 60;
                break;
            case "Grapes":
                cost = 40;
                break;
        }
        return cost * quantity;
    }

    private void clearFields() {
        customerNameEditText.setText("");
        mobileNumberEditText.setText("");
        fruitSpinner.setSelection(0);
        quantityEditText.setText("");
    }
}